# Open-World Strong Evidence Bundle

- ok: True
- run_dir: D:/AI/WordModule/tests/artifacts/open_world_strong_evidence_20260204_110537_258

## Steps

| step | ok | seconds | moved_dirs | stdout | stderr |
|---|---:|---:|---:|---|---|
| validate_all | 1 | 21.03 | 1 | [validate_all.stdout.txt](logs/validate_all.stdout.txt) | [validate_all.stderr.txt](logs/validate_all.stderr.txt) |
| holography_grid_quick | 1 | 0.49 | 1 | [holography_grid_quick.stdout.txt](logs/holography_grid_quick.stdout.txt) | [holography_grid_quick.stderr.txt](logs/holography_grid_quick.stderr.txt) |
| holography_noise_sweep_quick | 1 | 2.47 | 1 | [holography_noise_sweep_quick.stdout.txt](logs/holography_noise_sweep_quick.stdout.txt) | [holography_noise_sweep_quick.stderr.txt](logs/holography_noise_sweep_quick.stderr.txt) |
| expression_grounded_quick | 1 | 0.29 | 1 | [expression_grounded_quick.stdout.txt](logs/expression_grounded_quick.stdout.txt) | [expression_grounded_quick.stderr.txt](logs/expression_grounded_quick.stderr.txt) |
| island10_sweep_quick | 1 | 0.15 | 1 | [island10_sweep_quick.stdout.txt](logs/island10_sweep_quick.stdout.txt) | [island10_sweep_quick.stderr.txt](logs/island10_sweep_quick.stderr.txt) |
| open_policy_matrix | 1 | 1.31 | 1 | [open_policy_matrix.stdout.txt](logs/open_policy_matrix.stdout.txt) | [open_policy_matrix.stderr.txt](logs/open_policy_matrix.stderr.txt) |
| open_posterior_ablation | 1 | 5.21 | 1 | [open_posterior_ablation.stdout.txt](logs/open_posterior_ablation.stdout.txt) | [open_posterior_ablation.stderr.txt](logs/open_posterior_ablation.stderr.txt) |
| open_env_compare | 1 | 1.04 | 1 | [open_env_compare.stdout.txt](logs/open_env_compare.stdout.txt) | [open_env_compare.stderr.txt](logs/open_env_compare.stderr.txt) |
| open_ood_sweep_quick | 1 | 37.79 | 1 | [open_ood_sweep_quick.stdout.txt](logs/open_ood_sweep_quick.stdout.txt) | [open_ood_sweep_quick.stderr.txt](logs/open_ood_sweep_quick.stderr.txt) |
| open_ood_axis | 1 | 33.76 | 1 | [open_ood_axis.stdout.txt](logs/open_ood_axis.stdout.txt) | [open_ood_axis.stderr.txt](logs/open_ood_axis.stderr.txt) |
| expression_artifacts_quick | 1 | 56.74 | 1 | [expression_artifacts_quick.stdout.txt](logs/expression_artifacts_quick.stdout.txt) | [expression_artifacts_quick.stderr.txt](logs/expression_artifacts_quick.stderr.txt) |
| style_growth_migration | 1 | 0.35 | 1 | [style_growth_migration.stdout.txt](logs/style_growth_migration.stdout.txt) | [style_growth_migration.stderr.txt](logs/style_growth_migration.stderr.txt) |
| expression_compare_quick | 1 | 54.94 | 1 | [expression_compare_quick.stdout.txt](logs/expression_compare_quick.stdout.txt) | [expression_compare_quick.stderr.txt](logs/expression_compare_quick.stderr.txt) |

## How to Review

- validate_all：查看 steps/validate_all/*/evidence_index.md 与 thresholds_spec_validation.md
- island10_sweep_*：查看 meta_report.md（均值/CI 与相对 baseline 提升）
- open_policy_matrix：查看 rows.json / report.md（不同 posterior × 环境对比）
- open_posterior_ablation：查看 report.md（消融点位与 gate 通过情况）
- open_env_compare：查看 report.md（numeric vs engine OOD）
- open_ood_sweep_*：查看 report.md（更强漂移/预算/地平线等真实 OOD 曲线）
- open_ood_axis：查看 report.md（连续难度轴：漂移更频繁/噪声更大，定位拐点）

