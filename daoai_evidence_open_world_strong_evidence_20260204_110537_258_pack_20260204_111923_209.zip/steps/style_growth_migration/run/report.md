# WMV2 Style Growth Migration

- ok: True
- bundle_dir: D:/AI/WordModule/tests/artifacts/open_world_strong_evidence_20260204_110537_258
- growth_state: D:/AI/WordModule/tests/artifacts/wmv2_style_growth_migration_20260204_110829_710/growth_state.json

## Scenarios

| mode | ok | notes |
|---|---:|---|
| stable | 1 | changed_vs_prev=0/3 |
| watch | 1 | changed_vs_prev=1/3 |
| alert | 1 | changed_vs_prev=2/3 |

