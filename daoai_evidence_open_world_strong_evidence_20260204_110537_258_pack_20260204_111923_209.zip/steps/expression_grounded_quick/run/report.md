# WMV2 Expression Benchmark

- run_dir: D:/AI/WordModule/tests/artifacts/wmv2_expression_benchmark_20260204_110601_616
- backend: offline
- mode: grounded
- ok: True

| case | kind | ok |
|---|---|---:|
| qa_001 | open_qa_explain | 1 |
| creative_001 | creative_grounded | 1 |
| dialog_001 | natural_interaction | 1 |

## Summary

- passed: 3/3 pass_rate=1.000

