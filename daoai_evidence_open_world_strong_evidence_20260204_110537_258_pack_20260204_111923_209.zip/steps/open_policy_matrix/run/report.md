# Island10 Open Policy Matrix

- repeats: 1 (seed_start=1, seed_count=40)

| name | open_env | posterior | detect | rec@target | regret_mean | dd_auc_p95 | post_drift_regret | rel_regret(vs numeric_heuristic) | rel_post_drift | artifact |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| numeric_heuristic | numeric | heuristic | 0.730 [0.730,0.730] | 0.762 [0.762,0.762] | 194.8 [194.8,194.8] | 695.3 [695.3,695.3] | 6576 [6576,6576] | 1.000 | 1.000 | tests\artifacts\island10_open_20260204_110601_968 |
| numeric_dao_a0.20 | numeric | dao_heuristic | 0.730 [0.730,0.730] | 0.794 [0.794,0.794] | 189.1 [189.1,189.1] | 695.3 [695.3,695.3] | 6389 [6389,6389] | 0.970 | 0.972 | tests\artifacts\island10_open_20260204_110602_188 |
| engine_heuristic | engine | heuristic | 0.730 [0.730,0.730] | 0.762 [0.762,0.762] | 194.8 [194.8,194.8] | 695.3 [695.3,695.3] | 6576 [6576,6576] | 1.000 | 1.000 | tests\artifacts\island10_open_20260204_110602_436 |
| engine_dao_a0.20 | engine | dao_heuristic | 0.730 [0.730,0.730] | 0.794 [0.794,0.794] | 189.1 [189.1,189.1] | 695.3 [695.3,695.3] | 6389 [6389,6389] | 0.970 | 0.972 | tests\artifacts\island10_open_20260204_110602_793 |
