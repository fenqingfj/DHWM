# WMV2 Expression Compare

- run_dir: D:/AI/WordModule/tests/artifacts/wmv2_expression_compare_20260204_110830_184
- bundle_dir: D:/AI/WordModule/tests/artifacts/open_world_strong_evidence_20260204_110537_258
- backends: deepseek
- judge: deepseek
- ok: True

| backend | ok | passed | pass_rate |
|---|---:|---:|---:|
| deepseek | 1 | 6/6 | 1.000 |

