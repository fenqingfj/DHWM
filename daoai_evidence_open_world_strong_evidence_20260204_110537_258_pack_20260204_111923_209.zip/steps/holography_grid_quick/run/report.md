# WMV2 Holography Benchmark

- run_dir: D:/AI/WordModule/tests/artifacts/wmv2_holography_benchmark_20260204_110558_565
- ok: True

| grid | boundary_nodes | compression | recon_ok | hash_ok | export_ms | recon_ms | total_ms |
|---|---:|---:|---:|---:|---:|---:|---:|
| 16x16 | 60 | 0.234 | 1 | 1 | 0.51 | 3.78 | 4.28 |
| 32x32 | 124 | 0.121 | 1 | 1 | 1.80 | 14.87 | 16.67 |
| 64x64 | 252 | 0.062 | 1 | 1 | 6.04 | 71.12 | 77.16 |

## Notes

- This benchmark is a proxy for holography: reconstructing an interior grid from boundary information.
- report.json contains full per-case details, including reconstruction metadata and timing.
