# WMV2 Expression Artifacts Benchmark

- run_dir: D:/AI/WordModule/tests/artifacts/wmv2_expression_artifacts_benchmark_20260204_110733_043
- bundle_dir: D:/AI/WordModule/tests/artifacts/open_world_strong_evidence_20260204_110537_258
- backend: deepseek
- ok: True

| case | kind | ok |
|---|---|---:|
| expr_bundle_001 | artifact_grounded_explain | 1 |
| expr_bundle_002 | artifact_grounded_summary | 1 |
| expr_bundle_003 | artifact_grounded_rewrite_pm | 1 |
| expr_bundle_004 | artifact_grounded_rewrite_exec | 1 |
| expr_bundle_005 | artifact_grounded_creative | 1 |
| expr_bundle_006 | artifact_grounded_multiturn | 1 |

- passed: 6/6 pass_rate=1.000

