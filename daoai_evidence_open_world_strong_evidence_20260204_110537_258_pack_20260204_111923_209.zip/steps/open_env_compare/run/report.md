# Island10 Open Env Compare

- numeric artifact: tests\artifacts\island10_open_20260204_110608_596
- engine artifact: tests\artifacts\island10_open_20260204_110608_924

| metric | numeric | engine | delta(engine-numeric) |
|---|---:|---:|---:|
| detect_rate | 0.677 | 0.677 | 0.000 |
| recover_to_target_rate | 0.760 | 0.760 | 0.000 |
| regret_mean | 175.3 | 175.3 | 0.0 |
| drawdown_auc_p95 | 688.2 | 688.2 | 0.0 |
| post_drift_regret_total | 9038 | 9038 | 0 |

- numeric error: none
- engine error: none
