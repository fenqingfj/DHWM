# Island10 Open OOD Pairwise (Paired Bootstrap CI)

- sweep_dir: D:/AI/WordModule/tests/artifacts/open_world_strong_evidence_20260204_110537_258/steps/open_ood_axis/run
- compare: heuristic -> dao_a0.20 (delta = b - a)
- cases: 6

| point | env | delta_detect | delta_rec@target | delta_regret_sum | delta_post_drift_total |
|---|---|---:|---:|---:|---:|
| base | engine | 0.000 [0.000,0.000] | 0.025 [0.000,0.075] | -362 [-973,0] | -186 [-502,0] |
| base | numeric | 0.000 [0.000,0.000] | 0.025 [0.000,0.075] | -362 [-973,0] | -186 [-502,0] |
| drift_events_4 | engine | 0.000 [0.000,0.000] | 0.000 [0.000,0.000] | -216 [-842,194] | -75 [-322,97] |
| drift_events_4 | numeric | 0.000 [0.000,0.000] | 0.000 [0.000,0.000] | -216 [-842,194] | -75 [-322,97] |
| high_noise | engine | 0.000 [0.000,0.000] | 0.000 [0.000,0.000] | 153 [-16,466] | 97 [-8,278] |
| high_noise | numeric | 0.000 [0.000,0.000] | 0.000 [0.000,0.000] | 153 [-16,466] | 97 [-8,278] |
