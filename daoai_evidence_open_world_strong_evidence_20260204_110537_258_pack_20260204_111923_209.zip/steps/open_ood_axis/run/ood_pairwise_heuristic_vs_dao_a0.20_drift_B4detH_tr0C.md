# Island10 Open OOD Pairwise (Paired Bootstrap CI)

- sweep_dir: D:/AI/WordModule/tests/artifacts/open_world_strong_evidence_20260204_110537_258/steps/open_ood_axis/run
- compare: heuristic -> dao_a0.20_drift_B4detH_tr0C (delta = b - a)
- cases: 6

| point | env | delta_detect | delta_rec@target | delta_regret_sum | delta_post_drift_total |
|---|---|---:|---:|---:|---:|
| base | engine | 0.000 [0.000,0.000] | 0.025 [0.000,0.075] | -362 [-973,0] | -186 [-502,0] |
| base | numeric | 0.000 [0.000,0.000] | 0.025 [0.000,0.075] | -362 [-973,0] | -186 [-502,0] |
| drift_events_4 | engine | -0.010 [-0.088,0.062] | 0.113 [0.050,0.194] | -10651 [-17916,-4264] | -3766 [-6498,-1467] |
| drift_events_4 | numeric | -0.010 [-0.088,0.062] | 0.113 [0.050,0.194] | -10651 [-17916,-4264] | -3766 [-6498,-1467] |
| high_noise | engine | 0.000 [0.000,0.000] | 0.000 [0.000,0.000] | 0 [0,0] | 0 [0,0] |
| high_noise | numeric | 0.000 [0.000,0.000] | 0.000 [0.000,0.000] | 0 [0,0] | 0 [0,0] |
