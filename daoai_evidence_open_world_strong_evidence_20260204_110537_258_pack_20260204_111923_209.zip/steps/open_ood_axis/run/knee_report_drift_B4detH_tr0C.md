# Island10 Open OOD Knee Report

- axis_dir: D:/AI/WordModule/tests/artifacts/open_world_strong_evidence_20260204_110537_258/steps/open_ood_axis/run
- pairwise: D:/AI/WordModule/tests/artifacts/open_world_strong_evidence_20260204_110537_258/steps/open_ood_axis/run/ood_pairwise_heuristic_vs_dao_a0.20_drift_B4detH_tr0C.md
- axis_points: 3

## delta_post_drift_total

| env | knee_strict (first CI-not-better) | knee_non_worse (first CI-worse) |
|---|---|---|
| engine | base | none |
| numeric | base | none |

## delta_regret_sum

| env | knee_strict (first CI-not-better) | knee_non_worse (first CI-worse) |
|---|---|---|
| engine | base | none |
| numeric | base | none |

## delta_rec@target

| env | knee_strict (first CI-not-better) | knee_non_worse (first CI-worse) |
|---|---|---|
| engine | base | none |
| numeric | base | none |

## delta_detect

| env | knee_strict (first CI-not-better) | knee_non_worse (first CI-worse) |
|---|---|---|
| engine | base | drift_events_4 |
| numeric | base | drift_events_4 |

## Series (post_drift_total)

| env | point | delta_post_drift_total | strict_better | non_worse |
|---|---|---:|---:|---:|
| engine | base | -186 [-502,0] | 0 | 1 |
| engine | drift_events_4 | -3766 [-6498,-1467] | 1 | 1 |
| engine | high_noise | 0 [0,0] | 0 | 1 |
| numeric | base | -186 [-502,0] | 0 | 1 |
| numeric | drift_events_4 | -3766 [-6498,-1467] | 1 | 1 |
| numeric | high_noise | 0 [0,0] | 0 | 1 |

