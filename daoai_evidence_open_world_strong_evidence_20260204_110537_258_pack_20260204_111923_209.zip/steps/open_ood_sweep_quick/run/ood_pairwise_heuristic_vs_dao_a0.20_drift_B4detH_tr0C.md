# Island10 Open OOD Pairwise (Paired Bootstrap CI)

- sweep_dir: D:/AI/WordModule/tests/artifacts/open_world_strong_evidence_20260204_110537_258/steps/open_ood_sweep_quick/run
- compare: heuristic -> dao_a0.20_drift_B4detH_tr0C (delta = b - a)
- cases: 6

| point | env | delta_detect | delta_rec@target | delta_regret_sum | delta_post_drift_total |
|---|---|---:|---:|---:|---:|
| base | engine | 0.000 [0.000,0.000] | 0.025 [0.000,0.075] | -362 [-973,0] | -186 [-502,0] |
| base | numeric | 0.000 [0.000,0.000] | 0.025 [0.000,0.075] | -362 [-973,0] | -186 [-502,0] |
| low_budget | engine | 0.000 [0.000,0.000] | 0.025 [0.000,0.075] | -401 [-1028,0] | -206 [-535,0] |
| low_budget | numeric | 0.000 [0.000,0.000] | 0.025 [0.000,0.075] | -401 [-1028,0] | -206 [-535,0] |
| more_drift | engine | 0.035 [-0.025,0.100] | 0.104 [0.040,0.173] | -13330 [-24872,-3923] | -4279 [-7636,-1312] |
| more_drift | numeric | 0.035 [-0.025,0.100] | 0.104 [0.040,0.173] | -13330 [-24872,-3923] | -4279 [-7636,-1312] |
