# Threshold Spec Validation

- ok: True
- version: 7

## Coverage
- rule_keys: 31 / 31
- templates_used: 6 / 6
- anchors_used: 0 / 0

