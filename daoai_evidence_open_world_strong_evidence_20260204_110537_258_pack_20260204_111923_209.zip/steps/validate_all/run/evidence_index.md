# WMV2 Evidence Index

- run_root: tests/artifacts/wmv2_validate_20260204_110537_398
- entries: 20

| suite | island | name | status | key metrics | checks | summary | report | manifest |
|---|---:|---|---|---|---|---|---|---|
| island10_research | 10 | active_experimentation_innovation | PASS | law_acc=0.900 | ok(4) | [island_10_summary.json](suites/island10_research/island10_research_20260204_030548/island_10_summary.json) | [report.md](suites/island10_research/island10_research_20260204_030548/report.md) | [manifest.json](suites/island10_research/island10_research_20260204_030548/manifest.json) |
| open | 2 | counterfactual_ecosystem_lv | PASS | succ=0.850, ece=0.352, brier=0.235, cost=183.00 | ok(3) | [summary.json](suites/open/island2_open_20260204_110550/summary.json) | — | [manifest.json](suites/open/island2_open_20260204_110550/manifest.json) |
| open | 7 | three_body_chaos | PASS | succ=0.660, ece=0.010, brier=0.000, cost=60.00 | ok(3) | [summary.json](suites/open/island7_open_20260204_110550_475/summary.json) | — | [manifest.json](suites/open/island7_open_20260204_110550_475/manifest.json) |
| open | 8 | dark_forest | PASS | succ=0.660, ece=0.013, brier=0.000, cost=54.00 | ok(3) | [summary.json](suites/open/island8_open_20260204_110552_747/summary.json) | — | [manifest.json](suites/open/island8_open_20260204_110552_747/manifest.json) |
| open | 10 | active_experimentation_innovation | PASS | ece=0.258, brier=0.256 | ok(7) | [summary.json](suites/open/island10_open_20260204_110557_830/summary.json) | — | [manifest.json](suites/open/island10_open_20260204_110557_830/manifest.json) |
| strict | — | — | PASS | — | — | [derivation_1_kepler_summary.json](suites/strict/six_islands_20260204_030537/derivation_1_kepler_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | — | — | PASS | — | — | [derivation_2_maxwell_wave_summary.json](suites/strict/six_islands_20260204_030537/derivation_2_maxwell_wave_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | — | — | PASS | — | — | [derivation_3_infinite_well_summary.json](suites/strict/six_islands_20260204_030537/derivation_3_infinite_well_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | — | — | PASS | — | — | [holography_grid_summary.json](suites/strict/six_islands_20260204_030537/holography_grid_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | — | — | PASS | — | — | [holography_physics_rt_summary.json](suites/strict/six_islands_20260204_030537/holography_physics_rt_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | — | — | PASS | — | — | [holography_strong_grid_summary.json](suites/strict/six_islands_20260204_030537/holography_strong_grid_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | 1 | nbody_gravity_orbit | PASS | — | ok(3) | [island_1_summary.json](suites/strict/six_islands_20260204_030537/island_1_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | 2 | counterfactual_ecosystem_lv | PASS | — | ok(4) | [island_2_summary.json](suites/strict/six_islands_20260204_030537/island_2_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | 3 | micro_macro_economy | PASS | — | ok(2) | [island_3_summary.json](suites/strict/six_islands_20260204_030537/island_3_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | 4 | structure_discovery_wl | PASS | — | ok(2) | [island_4_summary.json](suites/strict/six_islands_20260204_030537/island_4_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | 5 | lever_equilibrium | PASS | — | ok(2) | [island_5_summary.json](suites/strict/six_islands_20260204_030537/island_5_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | 6 | coupled_evolution | PASS | — | ok(3) | [island_6_summary.json](suites/strict/six_islands_20260204_030537/island_6_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | 7 | three_body_chaos | PASS | rmse=0.026, e_err=0.000 | ok(2) | [island_7_summary.json](suites/strict/six_islands_20260204_030537/island_7_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | 8 | dark_forest | PASS | survival=0.005, stealth=0.752 | ok(3) | [island_8_summary.json](suites/strict/six_islands_20260204_030537/island_8_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |
| strict | 9 | maxwells_demon | PASS | eff=0.550, work=188853.6, bits=74926 | ok(4) | [island_9_summary.json](suites/strict/six_islands_20260204_030537/island_9_summary.json) | — | [manifest.json](suites/strict/six_islands_20260204_030537/manifest.json) |

