# WMV2 Thresholds Used

- rows: 45

| suite | island | check | threshold | detail |
|---|---:|---|---|---|
| island10_research | 10 | law_pred_acc>=min | 0.7 | metrics.active.law_pred_acc.mean>=0.7 |
| island10_research | 10 | steps_improve>=min | 0.2 | metrics.delta.steps_improve_ratio>=0.2 |
| island10_research | 10 | succ_improve>=min | 0.12 | metrics.delta.success_improve_abs>=0.12 |
| island10_research | 10 | viol_mean<=max | 0.2 | metrics.active.violations.mean<=0.2 |
| open | 2 | brier<=max | 0.4 | calibration.brier<=0.4 |
| open | 2 | ece<=max | 0.4 | calibration.ece<=0.4 |
| open | 2 | episodes>=min | 40 | episodes>=40 |
| open | 7 | brier<=max | 0.35 | calibration.brier<=0.35 |
| open | 7 | ece<=max | 0.4 | calibration.ece<=0.4 |
| open | 7 | episodes>=min | 30 | episodes>=30 |
| open | 8 | brier<=max | 0.35 | calibration.brier<=0.35 |
| open | 8 | ece<=max | 0.4 | calibration.ece<=0.4 |
| open | 8 | episodes>=min | 30 | episodes>=30 |
| open | 10 | drift.delay_p95<=max | 10.0 | drift.delay_detected.p95<=10.0 |
| open | 10 | drift.detect_rate>=min | 0.6 | drift.detect_rate>=0.6 |
| open | 10 | drift.events_total>=min | 20 | drift.events_total>=20 |
| open | 10 | episodes>=min | 40 | episodes>=40 |
| open | 10 | recovery.recover_rate>=min | 0.5 | recovery.recover_rate>=0.5 |
| open | 10 | recovery.steps_p95<=max | 15.0 | recovery.recovery_steps_detected.p95<=15.0 |
| open | 10 | recovery.target_events>=min | 20 | recovery.recover_to_target.events_total>=20 |
| strict | 1 | extrema>2 | 2 | extrema>2 |
| strict | 1 | r_max/r_min<2 | 2.0 | r_max/max(r_min)<2.0 |
| strict | 1 | r_min>10 | 10.0 | r_min>10.0 |
| strict | 2 | grass_recover>1.3x_trough | 0.00055409455476727 | grass_recover>grass_trough*1.3 |
| strict | 2 | grass_trough<0.6x | 331.4880251387601 | grass_trough<base_grass*0.6 |
| strict | 2 | rabbit_peak>1.5x | 318.5965033053626 | rabbit_peak>base_rabbit*1.5 |
| strict | 2 | rabbit_trough<0.8x | 169.9181350961934 | rabbit_trough<base_rabbit*0.8 |
| strict | 3 | shock_gdp<0.85x | 1.8700000000000012 | shock_gdp<base_gdp*0.85 |
| strict | 3 | shock_unemp>+0.05 | 0.35000000000000026 | shock_unemployment>base_unemployment+0.05 |
| strict | 4 | deg_equal | [1, 1, 2, 2] | degree_1==degree_2 |
| strict | 4 | deg_pattern | [1, 1, 2, 2] | degree_1==[1,1,2,2] |
| strict | 5 | residual<1e-6 | 1e-06 | residual<1e-6 |
| strict | 5 | |hand_energy-10|<=0.1 | 0.1 | abs(hand_energy-10)<=0.1 |
| strict | 6 | d1<=0.7*d0 | 2.0999999999999996 | d1<=max(0,d0*0.7) |
| strict | 6 | o0!=o1 | 310445604864 | o0!=o1 |
| strict | 6 | w0!=w1 | 310445604864 | w0!=w1 |
| strict | 7 | energy_error<max | 0.001 | energy_error<0.001 |
| strict | 7 | rmse<max | 0.1 | rmse_first_steps<0.1 |
| strict | 8 | stealth>min | 0.6 | stealth_emergence>0.6 |
| strict | 8 | survival<max | 0.5 | survival_rate<0.5 |
| strict | 8 | survival>min | 0.0 | survival_rate>0.0 |
| strict | 9 | eff<max | 1.2 | landauer_efficiency<1.2 |
| strict | 9 | eff>min | 0.01 | landauer_efficiency>0.01 |
| strict | 9 | final<initial | 1.0 | final_entropy<initial_entropy |
| strict | 9 | no_violation | false | violation_detected==False |

