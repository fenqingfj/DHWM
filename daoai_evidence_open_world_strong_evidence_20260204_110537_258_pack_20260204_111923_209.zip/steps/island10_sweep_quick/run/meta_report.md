# Island 10 Sweep Report

- run_id: 20260204_030601
- best_key: p0_step25_budget50
- seeds: [1, 2, 3, 4, 5]

| key | step_limit | budget | law_acc | steps_to_conf | success_rate | violations | total_cost | final_goal | delta_steps | delta_succ |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| p0_step25_budget50 | 25 | 50.0 | 1.000 | 2.000 | 0.800 | 0.000 | 29.580 | 124.010 | 0.881 | 0.800 |
| p1_step40_budget60 | 40 | 60.0 | 1.000 | 2.000 | 0.400 | 0.000 | 52.080 | 110.787 | 0.881 | 0.400 |

## Notes

- meta_summary.json contains all per-point metrics and per-law breakdown.
- Use tests/island_10_active_experimentation_validator.py for full evidence bundles (events_seed_*.jsonl).
