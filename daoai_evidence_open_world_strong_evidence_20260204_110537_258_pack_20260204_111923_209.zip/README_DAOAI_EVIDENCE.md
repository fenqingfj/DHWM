# DaoAi Evidence Bundle (WordModule)

本证据包用于把 WordModule 的“十岛(open-world)验证 + 强证据链验证 + 表达/成长验证”整理成可上传材料。

## 入口报告

- Open-World Strong Evidence 报告：report.md
- Step 结构化结果：step_results.json

## 如何复现（在 WordModule 仓库内）

```bash
python -m tools.open_world_strong_evidence --quick
```

## 本包包含的关键结论

- 强证据链：ok=True（见 report.md）
- Steps：
  - validate_all: ok=True seconds=21.028629779815674
  - holography_grid_quick: ok=True seconds=0.4917738437652588
  - holography_noise_sweep_quick: ok=True seconds=2.474236249923706
  - expression_grounded_quick: ok=True seconds=0.2876865863800049
  - island10_sweep_quick: ok=True seconds=0.15253520011901855
  - open_policy_matrix: ok=True seconds=1.3074698448181152
  - open_posterior_ablation: ok=True seconds=5.205846309661865
  - open_env_compare: ok=True seconds=1.039198637008667
  - open_ood_sweep_quick: ok=True seconds=37.78671860694885
  - open_ood_axis: ok=True seconds=33.761435747146606
  - expression_artifacts_quick: ok=True seconds=56.73750352859497
  - style_growth_migration: ok=True seconds=0.34528422355651855
  - expression_compare_quick: ok=True seconds=54.94412660598755

## 文件清单（相对路径）

- logs/expression_artifacts_quick.stderr.txt
- logs/expression_artifacts_quick.stdout.txt
- logs/expression_compare_quick.stderr.txt
- logs/expression_compare_quick.stdout.txt
- logs/expression_grounded_quick.stderr.txt
- logs/expression_grounded_quick.stdout.txt
- logs/holography_grid_quick.stderr.txt
- logs/holography_grid_quick.stdout.txt
- logs/holography_noise_sweep_quick.stderr.txt
- logs/holography_noise_sweep_quick.stdout.txt
- logs/island10_sweep_quick.stderr.txt
- logs/island10_sweep_quick.stdout.txt
- logs/open_env_compare.stderr.txt
- logs/open_env_compare.stdout.txt
- logs/open_ood_axis.stderr.txt
- logs/open_ood_axis.stdout.txt
- logs/open_ood_axis_knee_drift_b4deth_tr0c.stderr.txt
- logs/open_ood_axis_knee_drift_b4deth_tr0c.stdout.txt
- logs/open_ood_axis_pairwise_dao_a0_20.stderr.txt
- logs/open_ood_axis_pairwise_dao_a0_20.stdout.txt
- logs/open_ood_axis_pairwise_dao_a0_20_drift_B4detH_tr0C.stderr.txt
- logs/open_ood_axis_pairwise_dao_a0_20_drift_B4detH_tr0C.stdout.txt
- logs/open_ood_sweep_quick.stderr.txt
- logs/open_ood_sweep_quick.stdout.txt
- logs/open_ood_sweep_quick_analyze.stderr.txt
- logs/open_ood_sweep_quick_analyze.stdout.txt
- logs/open_ood_sweep_quick_pairwise_dao_a0_20.stderr.txt
- logs/open_ood_sweep_quick_pairwise_dao_a0_20.stdout.txt
- logs/open_ood_sweep_quick_pairwise_dao_a0_20_drift_B4detH_tr0C.stderr.txt
- logs/open_ood_sweep_quick_pairwise_dao_a0_20_drift_B4detH_tr0C.stdout.txt
- logs/open_policy_matrix.stderr.txt
- logs/open_policy_matrix.stdout.txt
- logs/open_posterior_ablation.stderr.txt
- logs/open_posterior_ablation.stdout.txt
- logs/style_growth_migration.stderr.txt
- logs/style_growth_migration.stdout.txt
- logs/validate_all.stderr.txt
- logs/validate_all.stdout.txt
- manifest.json
- report.md
- step_results.json
- steps/expression_artifacts_quick/run/cases.json
- steps/expression_artifacts_quick/run/report.json
- steps/expression_artifacts_quick/run/report.md
- steps/expression_compare_quick/run/cases.json
- steps/expression_compare_quick/run/report.json
- steps/expression_compare_quick/run/report.md
- steps/expression_grounded_quick/run/cases.json
- steps/expression_grounded_quick/run/report.json
- steps/expression_grounded_quick/run/report.md
- steps/holography_grid_quick/run/report.json
- steps/holography_grid_quick/run/report.md
- steps/holography_noise_sweep_quick/run/report.json
- steps/holography_noise_sweep_quick/run/report.md
- steps/island10_sweep_quick/run/meta_report.md
- steps/island10_sweep_quick/run/meta_summary.json
- steps/open_env_compare/run/engine_summary.json
- steps/open_env_compare/run/numeric_summary.json
- steps/open_env_compare/run/report.md
- steps/open_env_compare/run/rows.json
- steps/open_ood_axis/run/axis_meta.json
- steps/open_ood_axis/run/knee_report_drift_B4detH_tr0C.md
- steps/open_ood_axis/run/ood_pairwise_heuristic_vs_dao_a0.20.json
- steps/open_ood_axis/run/ood_pairwise_heuristic_vs_dao_a0.20.md
- steps/open_ood_axis/run/ood_pairwise_heuristic_vs_dao_a0.20_drift_B4detH_tr0C.json
- steps/open_ood_axis/run/ood_pairwise_heuristic_vs_dao_a0.20_drift_B4detH_tr0C.md
- steps/open_ood_sweep_quick/run/ood_analyze.json
- steps/open_ood_sweep_quick/run/ood_analyze.md
- steps/open_ood_sweep_quick/run/ood_pairwise_heuristic_vs_dao_a0.20.json
- steps/open_ood_sweep_quick/run/ood_pairwise_heuristic_vs_dao_a0.20.md
- steps/open_ood_sweep_quick/run/ood_pairwise_heuristic_vs_dao_a0.20_drift_B4detH_tr0C.json
- steps/open_ood_sweep_quick/run/ood_pairwise_heuristic_vs_dao_a0.20_drift_B4detH_tr0C.md
- steps/open_policy_matrix/run/report.md
- steps/open_policy_matrix/run/rows.json
- steps/open_posterior_ablation/run/report.md
- steps/open_posterior_ablation/run/rows.json
- steps/style_growth_migration/run/growth_state.json
- steps/style_growth_migration/run/report.json
- steps/style_growth_migration/run/report.md
- steps/validate_all/run/environment_snapshot.json
- steps/validate_all/run/evidence_index.md
- steps/validate_all/run/thresholds_spec.json
- steps/validate_all/run/thresholds_spec_validation.md
- steps/validate_all/run/thresholds_used.md

